class MyError(Exception):
    pass
